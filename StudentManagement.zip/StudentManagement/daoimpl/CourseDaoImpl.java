package StudentManagement.daoimpl;

import java.util.List;

import StudentManagement.dao.*;
import StudentManagement.data.*;
import StudentManagement.dto.*;

// This class provides implementations for data access operations related to course entities within the sms. 
///Declares a public class named CourseDaoImpl implementing CourseDao interface

public class CourseDaoImpl implements CourseDao {
	// Declares a variable named studentDetails of type StudentDetails
	StudentDetails studentDetails;
	// Constructor to initialize StudentDetails object

	public CourseDaoImpl() {
		studentDetails = StudentDetails.getObj(); // Initializes studentDetails with singleton instance of
													// StudentDetails

	}

	// Method to add a course to the list of courses
	@Override
	public Boolean add_course(Course course) {
		return studentDetails.getCourseList().add(course); // Adds the course to the list of courses and returns true if
															// successful
	}

	// Method to update information of an existing course
	@Override
	public Boolean update_course(Course course) {
		if (getCourseElementIndex(course.getCourse_id()) >= 0) { // Checks if course with given ID exists
			studentDetails.getCourseList().set(getCourseElementIndex(course.getCourse_id()), course); // Updates the
																										// course
																										// information
			return true; // Returns true indicating successful update
		}
		return false; // Returns false if course with given ID does not exist
	}

	// Method to delete a course from the list of courses
	@Override
	public Boolean delete_course(Integer course_id) {
		if (getCourseElementIndex(course_id) >= 0) { // Checks if course with given ID exists
			studentDetails.getCourseList().remove(getCourseElementIndex(course_id)); // Removes the course from the list
			return true; // Returns true indicating successful deletion
		}
		return false; // Returns false if course with given ID does not exist
	}

	// Method to get details of a specific course by ID
	@Override
	public Course get_course(Integer course_id) {
		return studentDetails.getCourseList().get(getCourseElementIndex(course_id)); // Retrieves the course object by
																						// its ID
	}

	// Method to get the index of a course in the list by ID
	@Override
	public int getCourseElementIndex(Integer course_id) {
		for (Course c : studentDetails.getCourseList()) { // Iterates through the list of courses
			if (c.getCourse_id().equals(course_id)) { // Checks if the course ID matches
				return studentDetails.getCourseList().indexOf(c); // Returns the index of the course
			}
		}
		return -1; // Returns -1 if course with given ID is not found
	}

	// Method to get the list of all courses
	@Override
	public List<Course> getCourses() {
		return studentDetails.getCourseList(); // Returns the list of all courses
	}

}
