package StudentManagement.daoimpl;

import java.util.List;

import StudentManagement.dao.StudentDao;
import StudentManagement.data.*;
import StudentManagement.dto.*;

// This class provides implementations for data access operations related to the student entities within the system
//Declares a public class named StudentDaoImpl implementing StudentDao interface
public class StudentDaoImpl implements StudentDao {
	// Declares a variable named studentDetails of type StudentDetails
	StudentDetails studentDetails;

	// Constructor to initialize StudentDetails object
	public StudentDaoImpl() {
		studentDetails = StudentDetails.getObj(); // Initializes studentDetails with singleton instance of
													// StudentDetails
	}

	// Method to add a student to the list of students
	@Override
	public void add_student(Student student) {
		studentDetails.getStudentList().add(student);
	}

	// Method to update information of an existing student
	@Override
	public void update_student(Student student) {
		if (getStudentElementIndex(student.getStudent_id()) >= 0) { // Checks if student with given ID exists
			studentDetails.getStudentList().set(getStudentElementIndex(student.getStudent_id()), student); // Updates
																											// the
																											// student
																											// information

		}
	}

	// Method to delete a student from the list of students
	@Override
	public void delete_student(Integer student_id) {
		if (getStudentElementIndex(student_id) >= 0) { // Checks if student with given ID exists
			studentDetails.getStudentList().remove(getStudentElementIndex(student_id)); // Removes the student from the
																						// list
		}
	}

	// Method to get details of a specific student by ID
	@Override
	public Student getStudent(Integer student_id) {
		return studentDetails.getStudentList().get(student_id); // Retrieves the student object by its ID
	}

	// Method to get the list of all students
	@Override
	public List<Student> getStudents() {
		return studentDetails.getStudentList();
	}

	// Method to get the index of a student in the list by ID
	@Override
	public int getStudentElementIndex(Integer student_id) {
		for (Student s : studentDetails.getStudentList()) { // Iterates through the list of students
			if (s.getStudent_id().equals(student_id)) { // Checks if the student ID matches
				return studentDetails.getStudentList().indexOf(s); // Returns the index of the student
			}
		}
		return -1; // Returns -1 if student with given ID is not found
	}

}
