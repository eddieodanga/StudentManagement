package StudentManagement.data;

import java.util.ArrayList;
import java.util.List;

import StudentManagement.dto.Course;
import StudentManagement.dto.Student;

//This singleton class was created to manage student and course data within the sms. 
// Declares a public class named StudentDetails
public class StudentDetails {
// Declares a static variable and initializes it to null
	private static StudentDetails studentDetails = null;
// List declarations
	List<Student> studentList;
	List<Course> courseList;
// Private constructor for initializing StudentDetails object
	private StudentDetails() {
	// Initializes studentList and CourseList as new ArrayList
		studentList = new ArrayList<>();
		courseList= new ArrayList<>();
	}
// Static method to get the singleton instance of StudentDetails
	public static StudentDetails getObj() {
		if(studentDetails != null) { //Checks if studentDetails is not null
			return studentDetails; // Returns the existing instance of StudentDetails
		}
		studentDetails = new StudentDetails(); //Creates a new instance of StudentDetails (if it doesn't exist)
		return studentDetails; // Returns the newly created instance of StudentDetails
	}
	
//Getter methods for StudentList and CourseList
	public List<Student> getStudentList(){
		return studentList;
	}
	public List<Course> getCourseList(){
		return courseList;
	}
}
