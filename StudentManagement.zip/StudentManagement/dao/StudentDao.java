package StudentManagement.dao;

import java.util.List;

import StudentManagement.dto.Student;

// This interface defines a contract for classes that provide data access operations related to student entities within the sms. 
// Declares an interface named StudentDao
public interface StudentDao {
// Methods for different CRUD operations
	void add_student(Student student);
	void update_student(Student student);
	void delete_student(Integer student_id);
	
//Methods for different getters
	Student getStudent(Integer student_id);
	List<Student> getStudents();
	int getStudentElementIndex(Integer student_id);
}
