package StudentManagement.dao;

import java.util.List;

import StudentManagement.dto.Course;


//// This interface defines a contract for classes that provide data access operations related to course entities within the sms.
// Declares an interface named CourseDao
public interface CourseDao {
// Methods for CRUD operations
	Boolean add_course(Course course);
	Boolean update_course(Course course);
	Boolean delete_course(Integer course_id);
	
//Methods for getters
	Course get_course(Integer course_id);
	int getCourseElementIndex(Integer course_id);
	List<Course> getCourses();
}
