package StudentManagement.dto;

// This class serves as a blueprint for creating objects that represent courses within the SMS. 
//Class and variable declaration
public class Course {
	Integer course_id;
	String course_name;
	Double course_fee;

// Default constructor for Course class
	public Course() {

	}

// Constructor for initializing Course object with provided values
	public Course(Integer course_id, String course_name, Double course_fee) {
// Assign the value of each parameter to their respective variable
		this.course_id = course_id;
		this.course_name = course_name;
		this.course_fee = course_fee;
	}

//Getter methods for Course_ID, Course_name, and Course_fee
	public Integer getCourse_id() {
		return course_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public Double getCourse_fee() {
		return course_fee;
	}

// Overrides the default toString() method to provide a custom string representation of the Course object
	@Override
	public String toString() {
		return "Course [course_id=" + course_id + ", course_name=" + course_name + ", course_fee=" + course_fee + "]";
	}

// Setter methods for Course_ID, Course_name, and Course_fee
	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public void setCourse_fee(Double course_fee) {
		this.course_fee = course_fee;
	}

}
