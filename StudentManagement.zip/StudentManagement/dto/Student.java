package StudentManagement.dto;

// This class serves as a blueprint for creating the objects that represent students in the management system. 
// Class and variable declaration 

public class Student {
	Integer student_id;
	String student_name;
	Integer student_age;
	Course course;

// Constructor for initializing Student object with values
	public Student(Integer student_id, String student_name, Integer student_age, Course course) {
// Assign the value of each parameter to their respective variable
		this.student_id = student_id;
		this.student_name = student_name;
		this.student_age = student_age;
		this.course = course;
	}

// Getter methods to retrieve student ID and student name
	public Integer getStudent_id() {
		return student_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	// Overrides the default toString() method to provide a custom string
	// representation
	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", student_name=" + student_name + ", student_age=" + student_age
				+ ", course=" + course + "]";
	}

	// Getter methods for Student age and Course
	public Integer getStudent_age() {
		return student_age;
	}

	public Course getCourse() {
		return course;
	}

	// Setter methods for Student ID, Student Name, Student Age, and Course
	public void setStudent_id(Integer student_id) {
		this.student_id = student_id;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public void setStudent_age(Integer student_age) {
		this.student_age = student_age;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

}
